library (
	name: "Logging",
	namespace: "davegut",
	author: "Dave Gutheinz",
	description: "Common Logging and info gathering Methods",
	category: "utilities",
	documentationLink: ""
)
//	Modified by hubitrep in 2026. Changes: https://github.com/hubitrep/SamsungTvRemote#changes

def nameSpace() { return "davegut" }

def version() { return "2.4.2" }

def label() {
	if (device) { 
		return device.displayName + "-${version()}"
	} else { 
		return app.getLabel() + "-${version()}"
	}
}

def listAttributes() {
	def attrData = device.getCurrentStates()
	Map attrs = [:]
	attrData.each {
		attrs << ["${it.name}": it.value]
	}
	return attrs
}

def setLogsOff() {
	def logData = [logEnable: logEnable]
	if (logEnable) {
		runIn(1800, debugLogOff)
		logData << [debugLogOff: "scheduled"]
	}
	return logData
}

def logTrace(msg){ log.trace "${label()}: ${msg}" }

def logInfo(msg) { 
	if (infoLog != false) { log.info "${label()}: ${msg}" }		//	unset counts as on
}

def debugLogOff() {
	if (device) {
		device.updateSetting("logEnable", [type:"bool", value: false])
	} else {
		app.updateSetting("logEnable", false)
	}
	logInfo("debugLogOff")
}

def logDebug(msg) {
	if (logEnable) { log.debug "${label()}: ${msg}" }
}

def logWarn(msg) { log.warn "${label()}: ${msg}" }

def logError(msg) { log.error "${label()}: ${msg}" }
