/*	===== HUBITAT INTEGRATION VERSION =====================================================
Hubitat - Samsung TV Remote Driver
		Copyright 2022 Dave Gutheinz
License:  https://github.com/DaveGut/HubitatActive/blob/master/KasaDevices/License.md
===== 2024 Version 2.3.9 ====================================================================
a.  Created preset functions (create, execute, trigger). Function work with and without
	SmartThings.  SEE DOCUMENTATION.
b.	Added buttons to support preset functions in dashboards.
c.	Added app codes to built-in app search list.
d.  Created methods to support adding running app automatically to state.appData
	if the SmartThings interface is enabled.
===== Modifications =======================================================================
This file was modified by hubitrep in 2026 (versions 2.3.10 and later).
Changes: https://github.com/hubitrep/SamsungTvRemote#changes
===========================================================================================*/
def driverVer() { return version() }
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

metadata {
	definition (name: "Samsung TV Remote",
				namespace: "davegut",
				author: "David Gutheinz",
				singleThreaded: true,
				importUrl: "https://raw.githubusercontent.com/hubitrep/SamsungTvRemote/main/SamsungTVRemote.groovy"
			   ){
		capability "Refresh"
		capability "Configuration"
		capability "Initialize"
		capability "SamsungTV"
		command "showMessage", [[name: "Not Implemented"]]
		capability "Switch"
		capability "PushableButton"
		capability "Variable"
	}
	preferences {
		input ("deviceIp", "text", title: "Samsung TV Ip", defaultValue: "")
		if (deviceIp) {
			List modeOptions = ["ART_MODE", "Ambient", "none"]
			if (getDataValue("frameTv") == "false") {
				modeOptions = ["Ambient", "none"]
			}
			input ("tvPwrOnMode", "enum", title: "TV Startup Display", 
				   options: modeOptions, defaultValue: "none")
			input ("logEnable", "bool",  
				   title: "Enable debug logging for 30 minutes", defaultValue: false)
			input ("infoLog", "bool", 
				   title: "Enable information logging " + helpLogo(),
				   defaultValue: true)
			stPreferences()
		}
		input ("pollInterval","enum", title: "Power Polling Interval (seconds)",
			   options: ["off", "10", "20", "30", "60"], defaultValue: "60")
		input ("wsIdleClose", "enum", title: "Close idle websocket after (minutes)",
			   options: ["never", "10", "30", "60"], defaultValue: "never")
		tvAppsPreferences()
	}
}

String helpLogo() { // library marker davegut.kasaCommon, line 11
	return """<a href="https://github.com/DaveGut/HubitatActive/blob/master/SamsungTvRemote/README.md">""" +
		"""<div style="position: absolute; top: 10px; right: 10px; height: 80px; font-size: 20px;">Samsung TV Remote Help</div></a>"""
}

//	===== Installation, setup and update =====
def installed() {
	state.token = "12345678"
	def tokenSupport = "false"
	sendEvent(name: "wsStatus", value: "closed")
//	sendEvent(name: "numberOfButtons", value: "60")
	runIn(1, updated)
}

//	called on hub start: the socket did not survive the reboot
def initialize() {
	close()
}

def updated() {
	sendEvent(name: "numberOfButtons", value: "60")
	unschedule()
	close()
	["wsQueue", "currentFunction", "pendingPowerHold", "powerProbeAt",
	 "wsData", "standbyTest", "configured", "onPollCount"].each { state.remove(it) }
	sendEvent(name: "presetUpdateNext", value: "false")
	def updStatus = [:]
	if (!deviceIp) {
		logWarn("\n\n\t\t<b>Enter the deviceIp and Save Preferences</b>\n\n")
		updStatus << [status: "ERROR", data: "Device IP not set."]
	} else {
		if (!getDataValue("driverVersion") || getDataValue("driverVersion") != driverVer()) {
			updateDataValue("driverVersion", driverVer())
			updStatus << [driverVer: driverVer()]
		}
		if (logEnable) { runIn(1800, debugLogOff) }
		updStatus << [logEnable: logEnable, infoLog: infoLog]
		updStatus << [setOnPollInterval: setOnPollInterval()]
		sendEvent(name: "numberOfButtons", value: 60)
		sendEvent(name: "wsStatus", value: "closed")
		def action = configure()
		if (!state.appData) { state.appData = [:] }
		updStatus << [updApps: updateAppCodes()]
	}
	logInfo("updated: ${updStatus}")
}

def setOnPollInterval() {
	if (pollInterval == null) {
		pollInterval = "60"
		device.updateSetting("pollInterval", [type:"enum", value: "60"])
	}
	if (pollInterval == "60") {
		runEvery1Minute(onPoll)
	} else if (pollInterval != "off") {
		schedule("0/${pollInterval} * * * * ?",  onPoll)
	}
	return pollInterval
}

def configure() {
	def respData = [:]
	def tvData = [:]
	try{
		httpGet([uri: "http://${deviceIp}:8001/api/v2/", timeout: 5]) { resp ->
			tvData = resp.data
			runIn(1, getArtModeStatus)
		}
	} catch (error) {
		tvData << [status: "error", data: error]
		if (getDataValue("alternateWolMac")) {
			tvData << [action: "kept saved TV settings"]
		} else {
			logError("configure: TV Off during setup or Invalid IP address.\n\t\tTurn TV On and Run CONFIGURE or Save Preferences!")
		}

	}
	if (!tvData.status) {
		def wifiMac = tvData.device.wifiMac
		updateDataValue("deviceMac", wifiMac)
		def alternateWolMac = wifiMac.replaceAll(":", "").toUpperCase()
		updateDataValue("alternateWolMac", alternateWolMac)
		device.setDeviceNetworkId(alternateWolMac)
		def modelYear = "20" + tvData.device.model[0..1]
		updateDataValue("modelYear", modelYear)
		def frameTv = "false"
		if (tvData.device.FrameTVSupport) {
			frameTv = tvData.device.FrameTVSupport
		}
		updateDataValue("frameTv", frameTv)
		if (tvData.device.TokenAuthSupport) {
			tokenSupport = tvData.device.TokenAuthSupport
			updateDataValue("tokenSupport", tokenSupport)
		}
		def uuid = tvData.device.duid.substring(5)
		updateDataValue("uuid", uuid)
		saveTvInfo(tvData)
		updateDataValue("powerStateReported", (tvData.device.PowerState != null).toString())
		respData << [status: "OK", dni: alternateWolMac, modelYear: modelYear,
					 frameTv: frameTv, tokenSupport: tokenSupport]
		sendEvent(name: "artModeStatus", value: "none")		//	getArtModeStatus (scheduled above) asks a Frame
	} else {
		respData << tvData
	}
	runIn(1, stUpdate)
	logInfo("configure: ${respData}")
	return respData
}

//	for support: what the TV is and which REST API it serves
def saveTvInfo(Map reply) {
	if (reply.device?.modelName) { updateDataValue("modelName", reply.device.modelName) }
	if (reply.device?.model) { updateDataValue("platform", reply.device.model) }
	if (reply.version) { updateDataValue("apiVersion", reply.version) }
}

//	===== Polling/Refresh Capability =====
def onPoll() {
	def sendCmdParams = [
		uri: "http://${deviceIp}:8001/api/v2/",
		timeout: 6
	]
	asynchttpGet("onPollParse", sendCmdParams)
	//	after a reboot the attribute still says open; the in-memory socket state does not
	if (ws().phase == "closed" && device.currentValue("wsStatus") == "open") {
		sendEvent(name: "wsStatus", value: "closed")
	}
	if (getDataValue("driverVersion") != driverVer()) {
		updateDriver()
	}
}

def updateDriver() {
	logWarn("driver updated to ${driverVer()}")
	//	version-specific state migrations go here (old version still in getDataValue("driverVersion"))
	updateDataValue("driverVersion", driverVer())
	runIn(1, updated)
}

def onPollParse(resp, data) {
	def powerState = "NC"
	def onOff = "off"
	Map info = null
	if (resp.status == 200) {
		try {
			Map reply = new JsonSlurper().parseText(resp.data)
			info = reply?.device
			//	a device set up or updated while the TV was off has none yet
			if (info && !getDataValue("modelName")) { saveTvInfo(reply) }
		} catch (e) {
			logDebug([method: "onPollParse", error: "unparsable reply"])
		}
	}
	if (info != null) {
		powerState = info.PowerState
		String reported = (powerState != null).toString()
		if (getDataValue("powerStateReported") != reported) {
			//	firmware updates have dropped PowerState; power then comes from the websocket
			logInfo("onPollParse: [powerStateReported: ${reported}]")
			updateDataValue("powerStateReported", reported)
		}
		if (powerState == null) {
			//	newer firmware omits PowerState; fall back to remote-socket liveness
			powerState = "absent"
			Map s = ws()
			if (s.funct == "remote" && s.phase == "ready") {
				onOff = "on"
			} else if (s.funct == "frameArt" && s.phase != "closed") {
				return		//	the art channel is in use; don't replace it to probe
			} else if (!powerOffHeld()) {		//	a TV shutting down still accepts the socket
				probePower()
				return
			}
		}
	}
	if (powerState == "on") { onOff = "on" }
	setPowerState(onOff, [method: "onPollParse", httpStatus: resp.status, powerState: powerState])
}

//	open the remote socket; wsReady or a failure reports the result to setPowerState
def probePower() {
	Map s = ws()
	if (s.probeAt && now() - s.probeAt < 20000) { return }
	if (s.funct == "remote" && s.phase in ["connecting", "open"]) { return }
	s.probeAt = now()
	logDebug([method: "probePower"])
	connect("remote")
}

//	the TV answers for a few seconds after power-off: skip the next poll, plus 5 s
def powerOffHeld() {
	def secs = (pollInterval && pollInterval != "off") ? pollInterval.toInteger() : 30
	return state.powerOffAt && now() - state.powerOffAt < (secs + 5) * 1000
}

def setPowerState(onOff, Map logData) {
	//	recent websocket failure overrides a stale REST "on"
	if (onOff == "on" && state.lastWsFailure &&
		now() - state.lastWsFailure < 35000) {
		onOff = "off"
		logData << [wsFailed: true]
	}
	//	hold off through the post-off cooldown
	if (powerOffHeld()) {
		onOff = "off"
	}
	logData << [onOff: onOff]
	String prev = device.currentValue("switch")
	sendEvent(name: "switch", value: onOff)
	if (prev != onOff) {
		logData << [switch: onOff]
		if (onOff == "on") {
			//	startup display only after on(), not when a poll blip recovers
			if (state.powerOnAt && now() - state.powerOnAt < 120000) {
				runIn(5, setPowerOnMode)
			}
			runIn(5, refresh)
		} else {
			setPowerOffMode()
		}
	}
	if (onOff == "on") { state.powerOnAt = null }
	logDebug(logData)
}

//	===== Capability Switch =====
def on() {
	logInfo("on: [frameTv: ${getDataValue("frameTv")}]")
	state.powerOnAt = now()
	state.powerOffAt = null
	state.lastWsFailure = null
	//	WoL only: KEY_POWER is a toggle and can switch an on TV off
	def wolMac = getDataValue("alternateWolMac")
	def cmd = "FFFFFFFFFFFF$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac$wolMac"
	//	send to both WoL ports (9 and 7)
	["255.255.255.255:9", "255.255.255.255:7"].each { dest ->
		sendHubCommand(new hubitat.device.HubAction(cmd,
			hubitat.device.Protocol.LAN,
			[type: hubitat.device.HubAction.Type.LAN_TYPE_UDPCLIENT,
			 destinationAddress: dest,
			 encoding: hubitat.device.HubAction.Encoding.HEX_STRING,
			 ignoreResponse: true]))
	}
	//	the TV takes several seconds to boot
	runIn(10, onPoll)
	runIn(20, onPollAgain)
}

def onPollAgain() { onPoll() }

def setPowerOnMode() {
	logInfo("setPowerOnMode: [tvPwrOnMode: ${tvPwrOnMode}]")
	if(tvPwrOnMode == "ART_MODE") {
		getArtModeStatus()
		runIn(2, artMode)		//	after the status reply
	} else if (tvPwrOnMode == "Ambient") {
		ambientMode()
	}
}

def off() {
	logInfo("off: [frameTv: ${getDataValue("frameTv")}]")
	state.powerOffAt = now()	//	post-off cooldown for onPollParse
	state.powerOnAt = null
	Map s = ws()
	boolean ready = s.phase == "ready" && s.funct == "remote"
	if (getDataValue("frameTv") == "true") {
		//	Frame TV: short press = art mode, power-off needs a held press
		if (ready) {
			powerHold()
		} else {
			if (s.funct != "remote" && s.phase != "closed") { close() }
			s.holdAt = now()		//	wsReady starts the hold
			if (s.phase == "closed") { connect("remote") }
		}
	} else {
		sendKey("POWER")
		//	an open socket outlives the TV and would read as on: close once the key is out
		if (ready) { runIn(2, close) } else { ws().closeAfterSend = true }
		runIn(1, onPoll)
	}
}

def powerHold() {
	sendKey("POWER", "Press")
	runInMillis(3000, powerHoldRelease)
}

def powerHoldRelease() {
	sendKey("POWER", "Release")
	runIn(2, onPoll)
	runIn(3, close)
}

def setPowerOffMode() {
	logInfo("setPowerOfMode")
	sendEvent(name: "appId", value: " ")
	sendEvent(name: "appName", value: " ")
	sendEvent(name: "tvChannel", value: " ")
	sendEvent(name: "tvChannelName", value: " ")
	runIn(5, refresh)
}

def setVariable(valueString) {
	sendEvent(name: "variable", value: valueString)
}

def refresh() {
	if (stConnected()) {
		deviceRefresh()
	}
	runIn(4, updateTitle)
}

//	===== BUTTON INTERFACE =====
def push(pushed) {
	logDebug("push: button = ${pushed}, trigger = ${state.triggered}")
	if (pushed == null) {
		logWarn("push: pushed is null.  Input ignored")
		return
	}
	pushed = pushed.toInteger()
	switch(pushed) {
		//	===== Physical Remote Commands =====
		case 2 : mute(); break			// toggles mute/unmute
		case 3 : numericKeyPad(); break
		case 4 : Return(); break		//	Goes back one level on apps. I.e., if playing, goes to
										//	app main screen
		case 6 : artMode(); break
		case 7 : ambientMode(); break
		case 8 : arrowLeft(); break
		case 9 : arrowRight(); break
		case 10: arrowUp(); break
		case 11: arrowDown(); break
		case 12: enter(); break			//	Executes selected OSD item (both apps and tv menus.
		case 13: exit(); break			//	Exits last selected item (if playing in app, will exit
										//	and return to app main screen.  If on main screen, exits app.
		case 14: home(); break			//	toggles on/off the TV's smart control page.
		case 18: channelUp(); break
		case 19: channelDown(); break
		case 20: guide(); break
		case 21: volumeUp(); break
		case 22: volumeDown(); break
		//	===== Direct Access Functions
		case 23: menu(); break			//	Calls upd OSD setting menu for TV.
		case 26: channelList(); break
		case 27: play(); break			//	Player control (playing app media that is not streaming
		case 28: pause(); break			//	(i.e., a recording in app).
		case 29: stop(); break			//	Exits the playing recording, returns to menu
		//	===== Other Commands =====
		case 34: previousChannel(); break	//	aka back
		case 35: sourceToggle(); break		//	Changed from hdmi().  Goes to next active source.
		case 36: fastBack(); break		//	player control
		case 37: fastForward(); break	//	player control
		//	===== Application Interface =====
		case 42: toggleSoundMode(); break		//	ST function
		case 43: togglePictureMode(); break		//	ST function
		case 44: 
			// Allows opening an app by name.  Enter using dashboard tile variable
			//	which creates the attribute variable.
			def variable = device.currentValue("variable")			
			if (variable == null || variable == " ") {
				logWarn("{button44: error: null variable, action: use setVariable to enter the variable]")
			} else {
				appOpenByName(variable)
			}
			sendEvent(name: "variable", value: " ")
			break
		
		case 45:
			//	TV Channel Preset Function.  Allows adding TV channels without the
			//	SmartThing interface.
			def variable = device.currentValue("variable")			
			if (variable == null || variable == " ") {
				logWarn("{button45: error: null variable, action: use setVariable to enter the variable]")
				logWarn("{button45: variable must be in format PresetNo, TVCHANNEL, TVCHANNELTITLE]]")
			} else {
				def arr = variable.split(",")
				if (arr.size() == 3) {
					try {
						arr[0].trim().toInteger()
						arr[1].trim().toInteger()
						presetCreateTv(arr[0].trim(), arr[1].trim(), arr[2].trim())
					} catch (err) {
						logWarn("{button45: [variable: ${variable}, error: must be in format PresetNo, TVCHANNEL, TVCHANNELTITLE]]")
					}
				} else {
					logWarn("{button45: [variable: ${variable}, error: must be in format PresetNo, TVCHANNEL, TVCHANNELTITLE]]")
				}
			}
			sendEvent(name: "variable", value: " ")
			break
		case 46:
			//	TV Channel set.  Must first enter variable.
			def variable = device.currentValue("variable")			
			if (variable == null || variable == " ") {
				logWarn("{button46: error: null variable, action: use setVariable to enter the variable]")
			} else {
				channelSet(variable)
			}
			sendEvent(name: "variable", value: " ")
			break
		//	Trigger function.  Once pressed, the preset buttons become ADD for 5 seconds.
		case 50: presetUpdateNext(); break
		case 51: presetExecute("1"); break
		case 52: presetExecute("2"); break
		case 53: presetExecute("3"); break
		case 54: presetExecute("4"); break
		case 55: presetExecute("5"); break
		case 56: presetExecute("6"); break
		case 57: presetExecute("7"); break
		case 58: presetExecute("8"); break
		case 59: presetExecute("9"); break
		case 60: presetExecute("10"); break
		default:
			logDebug("push: Invalid Button Number!")
			break
	}
}

//	===== Libraries =====
//#include davegut.samsungTvTEST

#include davegut.samsungTvWebsocket
#include davegut.samsungTvApps
#include davegut.samsungTvPresets
#include davegut.SmartThingsInterface
#include davegut.samsungTvST
#include davegut.Logging
